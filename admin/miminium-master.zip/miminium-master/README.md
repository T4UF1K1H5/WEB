# Discontinued
I decided to discontinue the development of this templates to concentrate my efforts on other projects. I would be very grateful, if you want to continue this project in another repository. Thanks. :)

# What is it?
miminium is a fully responsive admin template. Based on Bootstrap 3 framework. modern design and full animation. [DEMO](http://akivaron.github.io/miminium/)

![screenshot](https://github.com/akivaron/miminium/blob/master/asset/img/ss.png "screenshot")
# License
MIMINIUM is an open source project, that is licensed under MIT. Please feel free to use.
